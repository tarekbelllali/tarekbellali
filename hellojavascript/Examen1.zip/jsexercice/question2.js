//Question 2 :  Boucle For pour affichage en document.write

var nb


for (var nb = 0; nb <= 95; nb+=5){
    document.write(nb.toString() + " ");
    }

document.write("<br>");


for (var nb = 100; nb <= 195; nb+=5){
    document.write(nb.toString() + " ");
    }

document.write("<br>");


for (var nb = 200; nb <= 295; nb+=5){
    document.write(nb.toString() + " ");
}

document.write("<br>");

for (var nb = 300; nb <= 395; nb+=5){
    document.write(nb.toString() + " ");
}

 document.write("<br>");


for (var nb = 400; nb <= 495; nb+=5){
    document.write(nb.toString() + " ");
}nb

document.write("<br>");


for (var nb = 500; nb <= 595; nb+=5){
    document.write(nb.toString() + " ");
}

 document.write("<br>");


 for (var nb = 600; nb <= 695; nb+=5){
     document.write(nb.toString() + " ");
 }

 document.write("<br>");


 for (var nb = 700; nb <= 795; nb+=5){
     document.write(nb.toString() + " ");
 }

 document.write("<br>");


for (var nb = 800; nb <= 895; nb+=5){
    document.write(nb.toString() + " ");
}

  document.write("<br>");


for (var nb = 900; nb <= 995; nb+=5){
    document.write(nb.toString() + " ");
}
